package pages;

import AbstractClass.AbstractComponent;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends AbstractComponent {

    @FindBy(id = "user-name")
    WebElement Byusername;

    @FindBy(id = "password")
    WebElement Bypassword;

    @FindBy(id = "login-button")
    WebElement submit;


    public LoginPage(WebDriver driver) {
        super(driver); // this will add driver to super class constructor
        this.driver = driver; // initiate the driver with the driver
        PageFactory.initElements(driver, this); // initialize the page factory elemenets.
    }

    public void login(String username, String password) throws InterruptedException {
        Byusername.sendKeys(username);
        Bypassword.sendKeys(password);
    }

    public void cLickLogin(){
        submit.click();
    }

}
