package StepDefinations;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import pages.LoginPage;


public class LoginStepDefination extends LoginPage {


    public LoginStepDefination(WebDriver driver) {
        super(driver);
    }

    @Given("^The title of Login page$")
    public void verify_the_page_title() {
        getTitle();
    }

    @When("^User enters \"(.*)\" and \"(.*)\"$")
    public void enter_username_and_password(String username, String password) throws Throwable {

        login(username, password);
    }

    @Then("^click login button$")
    public void click_login_btn() {
        cLickLogin();
    }

}
