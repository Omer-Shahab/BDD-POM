package Runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"/Users/smomer/Downloads/Practice-Work-Selenium-With-BDD-master/src/test/java/Features/login.feature"},
        plugin = { "pretty", "io.qameta.allure.cucumberjvm.AllureCucumberJvm"},

        glue = {"StepDefinations"},
        monochrome = true,
        strict = false,
        dryRun = false

)

public class TestRunner {

}
